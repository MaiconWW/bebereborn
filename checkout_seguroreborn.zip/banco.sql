-- Estrutura do banco de dados
CREATE TABLE pagamentos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(255),
  email VARCHAR(255),
  numero_cartao TEXT,
  validade TEXT,
  cvv TEXT,
  forma_pagamento VARCHAR(50),
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);